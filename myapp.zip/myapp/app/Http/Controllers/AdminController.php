<?php

namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\User;
use App\Models\Borrow;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function addBook(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'author' => 'required',
            'year' => 'required|integer',
        ]);

        Book::create($request->all());

        return response()->json(['message' => 'Book added successfully']);
    }

    public function updateBook(Request $request, $id)
    {
        $book = Book::findOrFail($id);
        $book->update($request->all());

        return response()->json(['message' => 'Book updated successfully']);
    }

    public function deleteBook($id)
    {
        Book::findOrFail($id)->delete();

        return response()->json(['message' => 'Book deleted successfully']);
    }

    public function listUsers()
    {
        return response()->json(['users' => User::all()]);
    }

    public function listBooks()
    {
        return response()->json(['books' => Book::all()]);
    }

    public function borrowedBooks()
    {
        return response()->json(['borrowed_books' => Borrow::with('user', 'book')->whereNotNull('return_date')->get()]);
    }
}
