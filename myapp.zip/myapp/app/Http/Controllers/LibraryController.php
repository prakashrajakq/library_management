<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Borrow;
use App\Models\Fine;

class LibraryController extends Controller
{
    public function borrowBook(Request $request)
    {
        $request->validate([
            'book_id' => 'required|exists:books,id'
        ]);

        $book = Book::find($request->book_id);

        if ($book->status === 'borrowed') {
            return response()->json(['message' => 'Book already borrowed'], 400);
        }

        $borrow = Borrow::create([
            'user_id' => auth()->id(),
            'book_id' => $book->id,
            'borrow_date' => now(),
            'due_date' => now()->addDays(7),
        ]);

        $book->update(['status' => 'borrowed']);

        return response()->json(['message' => 'Book borrowed successfully']);
    }

    public function payFine(Request $request)
    {
        $fine = Fine::where('user_id', auth()->id())->where('id', $request->fine_id)->first();

        if (!$fine || $fine->paid) {
            return response()->json(['message' => 'No pending fine'], 400);
        }

        $fine->update(['paid' => true]);

        return response()->json(['message' => 'Fine paid successfully']);
    }
    public function returnBook(Request $request, $borrowId)
{
    $borrow = Borrow::findOrFail($borrowId);
    $borrow->return_date = now();
    $borrow->save();

    // Fine Calculation
    $dueDate = Carbon::parse($borrow->due_date);
    $returnDate = Carbon::parse($borrow->return_date);
    $overdueDays = $returnDate->diffInDays($dueDate, false);

    if ($overdueDays > 0) {
        $fineAmount = $overdueDays * 5; // Fine: $5 per day

        Fine::create([
            'user_id' => auth()->id(),
            'borrow_id' => $borrow->id,
            'amount' => $fineAmount,
            'paid' => false,
        ]);
    }

    $borrow->book->update(['status' => 'available']);

    return response()->json(['message' => 'Book returned successfully', 'fine' => $fineAmount ?? 0]);
}
}
