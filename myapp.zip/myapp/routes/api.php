<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\LibraryController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/borrow', [LibraryController::class, 'borrowBook']);
    Route::post('/pay-fine', [LibraryController::class, 'payFine']);
});

//admin routes
Route::middleware(['auth:sanctum', 'admin'])->group(function () {
    Route::post('/books', [AdminController::class, 'addBook']);
    Route::put('/books/{id}', [AdminController::class, 'updateBook']);
    Route::delete('/books/{id}', [AdminController::class, 'deleteBook']);
    Route::get('/users', [AdminController::class, 'listUsers']);
    Route::get('/books', [AdminController::class, 'listBooks']);
    Route::get('/borrowed-books', [AdminController::class, 'borrowedBooks']);
});

//return book
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/return/{borrowId}', [LibraryController::class, 'returnBook']);
});